import React from 'react'
import ProductContainer from '../components/ProductPage/ProductContainer'

const ProductPage = () => {
    return (
        <div>
  <ProductContainer/>

        </div>
    )
}

export default ProductPage