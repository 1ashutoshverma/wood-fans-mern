import React from 'react'
import ProductDetails from '../components/ProductPage/ProductDetails'

const ProductDetailsPage = () => {
    return (
        <div>
            <ProductDetails/>
        </div>
    )
}

export default ProductDetailsPage