import Cart from "../components/CartPage/Cart";

const CartPage = () => {
  return (
    <div>
      <Cart />
    </div>
  );
};

export default CartPage;
