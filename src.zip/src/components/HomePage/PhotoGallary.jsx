import React from 'react'
import style from "./PhotoGallary.module.css"
const PhotoGallary = () => {
    return (
        <div className={style.PhotogallaryMain}>
            <h1>Photo Gallery of our works</h1>
            <div className={style.Photogallary}>
                <div className={style.item1}>
                    {/* <img src="https://api.woodfans.ru/storage/uploads/images/rMIeWQJa0x5ziXS8T8zc3JzJ4zU00QwKiiO7Ras8.webp" alt="" /> */}
                </div>
                <div className={style.item2}>
                    {/* <img src="https://api.woodfans.ru/storage/uploads/images/rMIeWQJa0x5ziXS8T8zc3JzJ4zU00QwKiiO7Ras8.webp" alt="" /> */}
                </div>
                <div className={style.item3}>
                    {/* <img src="https://api.woodfans.ru/storage/uploads/images/rMIeWQJa0x5ziXS8T8zc3JzJ4zU00QwKiiO7Ras8.webp" alt="" /> */}
                </div>
                <div className={style.item4}>
                    {/* <img src="https://api.woodfans.ru/storage/uploads/images/rMIeWQJa0x5ziXS8T8zc3JzJ4zU00QwKiiO7Ras8.webp" alt="" /> */}
                </div>
                <div className={style.item5}>
                    {/* <img src="https://api.woodfans.ru/storage/uploads/images/rMIeWQJa0x5ziXS8T8zc3JzJ4zU00QwKiiO7Ras8.webp" alt="" /> */}
                </div>
                <div className={style.item6}>
                    {/* <img src="https://api.woodfans.ru/storage/uploads/images/rMIeWQJa0x5ziXS8T8zc3JzJ4zU00QwKiiO7Ras8.webp" alt="" /> */}
                </div>
                <div className={style.item7}>
                    {/* <img src="https://api.woodfans.ru/storage/uploads/images/rMIeWQJa0x5ziXS8T8zc3JzJ4zU00QwKiiO7Ras8.webp" alt="" /> */}
                </div>
                <div className={style.item8}>
                    {/* <img src="https://api.woodfans.ru/storage/uploads/images/rMIeWQJa0x5ziXS8T8zc3JzJ4zU00QwKiiO7Ras8.webp" alt="" /> */}
                </div>
            </div>
        </div>
    )
}

export default PhotoGallary