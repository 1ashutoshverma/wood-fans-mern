export const Add_To_Cart="Add_To_Cart";
export const Handle_Product_Navbar="Handle_Product_Navbar";